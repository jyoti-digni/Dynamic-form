<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" type="text/css" />

</head>

<body>
    <div class="min-h-screen bg-gray-50 flex items-center justify-center p-6">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('script-code'); ?>
    <script>
        Alpine.start()
    </script>
</body>

</html>
<?php /**PATH D:\Local\g-forms-main\resources\views/_layouts/auth.blade.php ENDPATH**/ ?>