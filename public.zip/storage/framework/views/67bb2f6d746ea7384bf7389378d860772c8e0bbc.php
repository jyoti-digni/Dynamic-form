<header class="fixed left-0 top-0 z-[999] w-full border-b bg-white transition-all">
    <div class="mx-auto w-full max-w-screen-2xl p-6 sm:px-12" data-aos="fade">
        <div class="flex items-center justify-between">
            <a class="block" href="<?php echo e(route('forms.index')); ?>"><?php echo e(config('app.name')); ?></a>

            <form action="<?php echo e(route('logout')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button class="flex items-center px-2 space-x-2 text-sm text-red-600">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.icons-dark.logout','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons-dark.logout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <span>Logout</span>
                </button>
            </form>
        </div>
    </div>
</header>
<?php /**PATH D:\Local\g-forms-main\resources\views/_layouts/header.blade.php ENDPATH**/ ?>