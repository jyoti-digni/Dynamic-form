<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" type="text/css" />

</head>

<body x-data>

    <?php echo $__env->make('_layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="pt-[68px] transition-all">
        <div class="mx-auto max-w-screen-2xl space-y-6 px-6 py-6 sm:px-12">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

    <?php echo $__env->yieldContent('modal'); ?>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('script-code'); ?>
    <script>
        Alpine.start()
    </script>
</body>

</html>
<?php /**PATH D:\Local\g-forms-main\resources\views/_layouts/app.blade.php ENDPATH**/ ?>