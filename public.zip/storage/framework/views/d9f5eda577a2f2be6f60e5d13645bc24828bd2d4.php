<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"
    stroke-width="2">
    <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h7" />
</svg>
<?php /**PATH D:\Local\g-forms-main\resources\views/components/icons-light/menu-alt2.blade.php ENDPATH**/ ?>