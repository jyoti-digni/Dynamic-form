<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-lg w-full bg-white border p-6">
        <form action="<?php echo e(route('login.request')); ?>" class="space-y-6" method="post">
            <div>
                <?php echo csrf_field(); ?>
                <div class="space-y-1">
                    <h1 class="text-xl font-semibold">Login</h1>
                    <p class="text-sm text-gray-500">Welcome back! Please enter your details</p>
                </div>
            </div>

            <div class="space-y-3">
                <div class="tw-form-group <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> tw-form-input-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="email">Email</label>
                    <input type="text" name="email" id="email" class="tw-form-control" value="<?php echo e(old('email')); ?>"
                        placeholder="Enter e-mail" />
                    <small class="tw-form-error-text">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>

                <div class="tw-form-group <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> tw-form-input-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" class="tw-form-control"
                        placeholder="Enter password" />
                    <small class="tw-form-error-text">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>
            </div>

            <button class="tw-btn bg-sky-500 text-white">
                <span>login</span>
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Local\g-forms-main\resources\views/login/index.blade.php ENDPATH**/ ?>